1. Please replace the Solver.java in package org.chocosolver.solver if you use a Choco 4.10.0. If you use other versions of Choco, add the following if statement into the validate procedure of Solver.java to make the searching not to update the objective bound at the sampling phase.

		if (!FPMS.sampling) {
			objectivemanager.updateBestSolution();
		}
		
2. The Example.java is an example of how to run FPMS.


If you have any suggestion or question, please contact: lihb905@nenu.edu.cn