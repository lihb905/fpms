package org.nenu.fpms;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;;

/**
 * This is an adaptation of the ECLAT algorithm for FPMS. 
 */
public class ECLAT {
	private final int minSupport;
	private final int shortest;
	private final int longest;
	private final int topNum;
	private final String[][] transactions;
	private final double[] transQualities;
	private TopFrequentPatterns topFPs;
	private final int transNum;
	private ArrayList<Node> array = new ArrayList<Node>();
	private Node[] hashTable;
	private ArrayList<String> reverseMap;
	private HashMap<String, Integer> siMap;
	private int foundFPNum = 0;
	private final boolean record2Size;

	public long miningStartStamp;
	public double timeout = 100;// in seconds
	public final boolean isMaximize;
	
	public ECLAT(String[][] trans,boolean isMax, double[] qs,int minSup,int s, int l, int tn) {
		transactions=trans;
		transNum=trans.length;
		transQualities=qs;
		minSupport=minSup;
		shortest =s ;
		longest = l;
		topNum=tn;
		isMaximize=isMax;
		topFPs = new TopFrequentPatterns(topNum);
		if (shortest <= 2) {
			record2Size = true;
		} else {
			record2Size = false;
		}
	}
	
	
	public FrequentPattern[] runFPM() {
		foundFPNum = 0;
		runMining();
		return topFPs.getSortedFPs();
	}



	public void runMining() {
		init();
		if (longest > 2) {
			start();
		}
	}

	Set[][] a;
	int itemNum = 0;

	public void init() {
		Set itemSet = new TreeSet();
		MyMap<Integer, Integer> itemMap = new MyMap<Integer, Integer>();
		siMap = new HashMap<String, Integer>();
		reverseMap = new ArrayList<String>();
		reverseMap.add("");
		int stringID = 1;
		for (int i = 0; i < transNum; i++) {
			String[] line = transactions[i];
			for (String item : line) {
				int v;
				if (siMap.containsKey(item)) {
					v = siMap.get(item);
				} else {
					v = stringID;
					reverseMap.add(item);
					siMap.put(item, v);
					stringID++;
				}
				itemSet.add(v);
				itemMap.add(v);
			}
		}
		ItemSet.limitSupport = minSupport;
		ItemSet.ItemSize = (Integer) itemMap.lastKey();
		ItemSet.TransSize = transNum;
		hashTable = new Node[ItemSet.ItemSize * 3];
		for (int i = 0; i < hashTable.length; i++) {
			hashTable[i] = new Node();
		}
		ArrayList<Double> supportNums = new ArrayList<Double>();
		Set oneItem = itemMap.keySet();
		int countOneItem = 0;
		for (Iterator it = oneItem.iterator(); it.hasNext();) {
			int key = (Integer) it.next();
			int value = (Integer) itemMap.get(key);
			supportNums.add((double) value);
			if (value >= ItemSet.limitSupport) {
				countOneItem++;
			}
		}
		itemNum = (Integer) itemMap.lastKey();
		a = new TreeSet[itemNum + 1][itemNum + 1];
		array.add(new Node());
		int counter = 0;
		for (int i1 = 0; i1 < transNum; i1++) {
			String[] line = transactions[i1];
			counter++;
			for (int i = 0; i < line.length; i++) {
				int sOne = siMap.get(line[i]);
				for (int j = i + 1; j < line.length; j++) {
					int sTwo = siMap.get(line[j]);
					if (a[sOne][sTwo] == null) {
						Set set = new TreeSet();
						set.add(counter);
						a[sOne][sTwo] = set;
						a[sTwo][sOne] = set;
					} else {
						a[sOne][sTwo].add(counter);
					}
				}
			}
		}

		ArrayList<Double> twoSupportNums = new ArrayList<Double>();
		for (int i = 1; i <= itemNum; i++) {
			for (int j = i + 1; j <= itemNum; j++) {
				if (a[i][j] != null) {
					twoSupportNums.add((double) a[i][j].size());
				}
			}
		}

		for (int i = 1; i <= itemNum; i++) {
			Node headNode = new Node();
			for (int j = i + 1; j <= itemNum; j++) {
				if (a[i][j] != null && a[i][j].size() >= ItemSet.limitSupport) {
					headNode.items++;
					ItemSet is = new ItemSet(true);
					is.item = 2;
					is.items.set(i);
					is.items.set(j);
					is.supports = a[i][j].size();
					for (Iterator it = a[i][j].iterator(); it.hasNext();) {
						int value = (Integer) it.next();
						is.trans.set(value);
					}
					if (record2Size) {
						recordFP(is.items, is.trans, is.supports);
						foundFPNum++;
					}
					if (headNode.first == null) {
						headNode.first = is;
						headNode.last = is;
					} else {
						headNode.last.next = is;
						headNode.last = is;
					}
				}
			}
			if (headNode.first != null) {
				array.add(headNode);
			}
		}

	}

	public boolean start() {
		boolean flag = true;
		ItemSet shareFirst = new ItemSet(false);
		int fpSize = 3;
		while (flag) {
			flag = false;
			for (int i = 1; i < array.size(); i++) {
				Node headNode = array.get(i);
				if (headNode.items > 1) {
					if (!generateLargeItemSet(headNode, shareFirst)) {
						return false;
					}
					if (fpSize < longest) {
						flag = true;
					}
				}
				clear(hashTable);
			}
			fpSize++;
		}
		return true;
	}

	public boolean generateLargeItemSet(Node headNode, ItemSet shareFirst) {

		BitSet bsItems = new BitSet(ItemSet.ItemSize);
		BitSet bsTrans = new BitSet(ItemSet.TransSize);
		BitSet containItems = new BitSet(ItemSet.ItemSize);
		BitSet bsItems2 = new BitSet(ItemSet.ItemSize);
		ItemSet oldCurrent = null, oldNext = null;
		oldCurrent = headNode.first;
		long countItems = 0;
		ItemSet newFirst = new ItemSet(false), newLast = newFirst;
		while (oldCurrent != null) {
			oldNext = oldCurrent.next;
			while (oldNext != null) {
				bsItems.clear();
				bsItems.or(oldCurrent.items);
				bsItems.and(oldNext.items);
				if (bsItems.cardinality() < oldCurrent.item - 1) {
					break;
				}
				containItems.clear();
				containItems.or(oldCurrent.items);
				containItems.or(oldNext.items);
				if (!containItems(containItems, bsItems2, newFirst)) {
					bsTrans.clear();
					bsTrans.or(oldCurrent.trans);
					bsTrans.and(oldNext.trans);
					if (bsTrans.cardinality() >= ItemSet.limitSupport) {
						ItemSet is = null;
						if (shareFirst.next == null) {
							is = new ItemSet(true);
						} else {
							is = shareFirst.next;
							shareFirst.next = shareFirst.next.next;
							is.items.clear();
							is.trans.clear();
							is.next = null;
						}
						is.item = (oldCurrent.item + 1);
						is.items.or(oldCurrent.items);
						is.items.or(oldNext.items);
						is.trans.or(oldCurrent.trans);
						is.trans.and(oldNext.trans);
						is.supports = is.trans.cardinality();
						if (is.items.cardinality() >= shortest) {
							recordFP(is.items, is.trans, is.supports);
							foundFPNum++;
						}
						countItems++;
						newLast.next = is;
						newLast = is;

					}
				}
				oldNext = oldNext.next;
			}
			oldCurrent = oldCurrent.next;
		}
		ItemSet temp1 = headNode.first;
		ItemSet temp2 = headNode.last;
		temp2.next = shareFirst.next;
		shareFirst.next = temp1;
		headNode.first = newFirst.next;
		headNode.last = newLast;
		headNode.items = countItems;
		return true;
	}

	public boolean containItems(BitSet containItems, BitSet bsItems2, ItemSet first) {
		long size = containItems.cardinality();
		int itemSum = 0;
		int temp = containItems.nextSetBit(0);
		while (true) {
			itemSum += temp;
			temp = containItems.nextSetBit(temp + 1);
			if (temp == -1) {
				break;
			}
		}
		int hash = itemSum % (ItemSet.ItemSize * 3);
		Node headNode = hashTable[hash].next;
		Node pre = hashTable[hash];
		while (true) {
			if (headNode == null) {
				Node node = new Node();
				node.bs.or(containItems);
				pre.next = node;
				return false;
			}
			if (headNode.bs.isEmpty()) {
				headNode.bs.or(containItems);
				return false;
			}
			bsItems2.clear();
			bsItems2.or(containItems);
			bsItems2.and(headNode.bs);
			if (bsItems2.cardinality() == size) {
				return true;
			}
			pre = headNode;
			headNode = headNode.next;
		}

	}

	public void clear(Node[] hashTable) {
		for (int i = 0; i < hashTable.length; i++) {
			Node node = hashTable[i].next;
			while (node != null) {
				node.bs.clear();
				node = node.next;
			}
		}
	}

	public void recordFP(BitSet items, BitSet trans, int supports) {
		String[] ass=new String[items.cardinality()];
		int temp = items.nextSetBit(0);
		String item = reverseMap.get(temp);
		int index=0;
		ass[index++]=item;
		while (true) {
			temp = items.nextSetBit(temp + 1);
			if (temp == -1) {
				break;
			}
			item = reverseMap.get(temp);
			ass[index++]=item;
		}
		double[] qualities=new double[trans.cardinality()];
		index=0;
		temp= trans.nextSetBit(0);
		qualities[index++] =transQualities[temp-1];
		while (true) {
			temp = trans.nextSetBit(temp + 1);
			if (temp == -1) {
				break;
			}
			qualities[index++]=transQualities[temp-1];
		}
		
		FrequentPattern fp = new FrequentPattern(items.cardinality(), supports, ass,qualities,isMaximize);
		topFPs.add(fp);

	}

}

class MyMap<T, E> extends TreeMap {
	public void add(T obj) {
		if (this.containsKey(obj)) {
			int value = (Integer) this.get(obj);
			this.put(obj, value + 1);
		} else
			this.put(obj, 1);
	}
}


class Node {
	public Node next=null;	
	public BitSet bs=new BitSet(ItemSet.ItemSize);
	public long items=0;
	public ItemSet first=null;
	public ItemSet last=null;
}

class ItemSet {
	public static int limitSupport;
	public static int ItemSize;
	public static int TransSize;
	public boolean flag = true;
	public int item = 0;
	public int supports = 0;
	public BitSet items = null;
	public BitSet trans = null;
	public ItemSet next = null;
	public ItemSet(boolean flag) {
		this.flag = flag;
		if (flag) {
			item = 0;
			supports = 0;
			items = new BitSet(ItemSize + 1);
			trans = new BitSet(TransSize + 1);
		}
	}
}