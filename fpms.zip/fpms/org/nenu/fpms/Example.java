package org.nenu.fpms;

import org.chocosolver.samples.AbstractProblem;
import org.chocosolver.solver.Model;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.search.strategy.Search;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;

/**
 * This is an example of combining FPMS with ABS to solve a Multidimensional-Knapsack-Problem instance.
 * @author Hongbo Li, released 08/08/2021 
 */

public class Example extends AbstractProblem {
	public int itemNum;
	public int dimNum;
	public int[][] weight;
	public int[] capacity;
	public int[] value;
	public int maxReward;
	public IntVar obj;
	public BoolVar[] items;
	public String instName = "mknap1_07_16537";

	public Example() {
	}

	public void setUP() {
		int[][] source = mk16;
		itemNum = source[0][0];
		dimNum = source[0][1];
		value = new int[itemNum];
		for (int i = 0; i < itemNum; i++) {
			value[i] = source[1][i];
		}

		capacity = new int[dimNum];
		for (int i = 0; i < dimNum; i++) {
			capacity[i] = source[i + 2][source[i + 2].length - 1];
		}

		weight = new int[dimNum][];
		for (int i = 0; i < dimNum; i++) {
			weight[i] = new int[itemNum];
			for (int j = 0; j < itemNum; j++) {
				weight[i][j] = source[i + 2][j];
			}
		}
		maxReward = 0;
		for (int i = 0; i < itemNum; i++) {
			maxReward += value[i];
		}
	}

	@Override
	public void buildModel() {
		model = new Model(instName);
		setUP();
		items = model.boolVarArray("item", itemNum);
		for (int i = 0; i < dimNum; i++) {
			model.scalar(items, weight[i], "<=", capacity[i]).post();
		}
		obj = model.intVar("OBJ", 0, maxReward);
		model.scalar(items, value, "=", obj).post();

	}

	public void configureSearch() {
		Solver solver = model.getSolver();
		model.setObjective(true, obj);
		AbstractStrategy fpms = new FPMS(items, 0, 0.1, 10);
		solver.setSearch(fpms, Search.activityBasedSearch(items));
	}

	public void solve() {
		Solver solver = model.getSolver();
		solver.showShortStatistics();
		solver.getObjectiveManager().<Integer>setCutComputer(obj -> obj);
		solver.findOptimalSolution(obj, true);
	}

	public static void main(String[] args) {
		new Example().execute(args);
	}

	public static int[][] mk16 = { { 50, 5 },
			{ 560, 1125, 300, 620, 2100, 431, 68, 328, 47, 122, 322, 196, 41, 25, 425, 4260, 416, 115, 82, 22, 631, 132,
					420, 86, 42, 103, 215, 81, 91, 26, 49, 420, 316, 72, 71, 49, 108, 116, 90, 738, 1811, 430, 3060,
					215, 58, 296, 620, 418, 47, 81, 16537 },
			{ 40, 91, 10, 30, 160, 20, 3, 12, 3, 18, 9, 25, 1, 1, 10, 280, 10, 8, 1, 1, 49, 8, 21, 6, 1, 5, 10, 8, 2, 1,
					0, 10, 42, 6, 4, 8, 0, 10, 1, 40, 86, 11, 120, 8, 3, 32, 28, 13, 2, 4, 800 },
			{ 16, 92, 41, 16, 150, 23, 4, 18, 6, 0, 12, 8, 2, 1, 0, 200, 20, 6, 2, 1, 70, 9, 22, 4, 1, 5, 10, 6, 4, 0,
					4, 12, 8, 4, 3, 0, 10, 0, 6, 28, 93, 9, 30, 22, 0, 36, 45, 13, 2, 2, 650 },
			{ 38, 52, 30, 42, 170, 9, 7, 20, 0, 3, 21, 4, 1, 2, 14, 310, 8, 4, 6, 1, 18, 15, 38, 10, 4, 8, 6, 0, 0, 3,
					0, 10, 6, 1, 3, 0, 3, 5, 4, 0, 30, 12, 16, 18, 3, 16, 22, 30, 4, 0, 650 },
			{ 38, 39, 32, 71, 80, 26, 5, 40, 8, 12, 30, 15, 0, 1, 23, 100, 0, 20, 3, 0, 40, 6, 8, 0, 6, 4, 22, 4, 6, 1,
					5, 14, 8, 2, 8, 0, 20, 0, 0, 6, 12, 6, 80, 13, 6, 22, 14, 0, 1, 2, 550 },
			{ 8, 71, 30, 60, 200, 18, 6, 30, 4, 8, 31, 6, 3, 0, 18, 60, 21, 4, 0, 2, 32, 15, 31, 2, 2, 7, 8, 2, 8, 0, 2,
					8, 6, 7, 1, 0, 0, 20, 8, 14, 20, 2, 40, 6, 1, 14, 20, 12, 0, 1, 550 }

	};

}
