package org.nenu.fpms;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import org.chocosolver.solver.ResolutionPolicy;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.search.limits.SolutionCounter;
import org.chocosolver.solver.search.loop.monitors.IMonitorSolution;
import org.chocosolver.solver.search.loop.move.Move;
import org.chocosolver.solver.search.loop.move.MoveRestart;
import org.chocosolver.solver.search.restart.MonotonicRestartStrategy;
import org.chocosolver.solver.search.strategy.Search;
import org.chocosolver.solver.search.strategy.assignments.DecisionOperatorFactory;
import org.chocosolver.solver.search.strategy.decision.Decision;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.search.strategy.strategy.IntStrategy;
import org.chocosolver.solver.variables.IntVar;

/**
 * 1. This is the Frequent pattern mining based search of "Finding good subtrees
 * for constraint optimization problems using frequent pattern mining. Proc. of
 * AAAI'20."
 * 2. The source code were developed in Choco 4.10.0
 * 3. This search strategy must be combined with other search strategies, e.g.,
 * if you want to combine FPMS with ABS, you should set the searching by
 * solver.setSearch(new FPMS(variables,*,*,*), Search.activityBasedSearch(variables));
 * 
 * @author Hongbo Li, released 08/08/2021
 * If you have any suggestion or question, feel free to contact: lihb905@nenu.edu.cn
 */
public class FPMS extends AbstractStrategy<IntVar> implements IMonitorSolution {
	public static boolean sampling = false;
	private int varNum;
	private IntStrategy randomSelector;
	private Solver solver;
	private Move rfMove;
	private final boolean isMaximize;
	private int currentSampleNum;
	private final int maxSampleNum;
	private final int topSampleNum;
	private TopSamples highQualitySamples;
	private final double topRate;
	private final int topFPnum;
	private FrequentPattern[] goodFPs;

	/**
	 * Some default parameters.
	 */
	private int shortestItemNum = 3;
	private int longestItemNum = 5;
	private int minSup = 20;

	/**
	 * In subtree, each pair of integers a, b specifies an assignment x[a]=b.
	 */
	private LinkedList<Integer> subtree;

	/**
	 * 
	 * @param variables: the decision variables. 
	 * Note: It is not recommended to put those intermediate variables in decision variables.
	 * @param seed: a random seed.
	 * @param tr: the top rate of samples considered as high quality sample solutions.
	 * @param tn: the top number of good frequent patterns.
	 */
	public FPMS(IntVar[] variables, int seed, double tr, int tn) {
		super(variables);
		varNum = variables.length;
		sampling = true;
		randomSelector = Search.randomSearch(variables, seed);
		solver = variables[0].getModel().getSolver();
		solver.plugMonitor(this);
		setRestartOnSolution();
		if (solver.getModel().getResolutionPolicy() == ResolutionPolicy.MINIMIZE) {
			isMaximize = false;
		} else {
			isMaximize = true;
		}
		topRate = tr;
		topFPnum = tn;
		int maxDS = 0;
		for (int i = 0; i < varNum; i++) {
			int ds = vars[i].getDomainSize();
			if (maxDS < ds) {
				maxDS = ds;
			}
		}
		topSampleNum = minSup * maxDS;
		maxSampleNum = (int) (topSampleNum / topRate);
		highQualitySamples = new TopSamples(topSampleNum, isMaximize);
		currentSampleNum = 0;
	}

	@Override
	public Decision<IntVar> getDecision() {
		if (sampling) {
			return randomSelector.getDecision();// the decisions made at
												// sampling phase
		} else {
			return getSubtreeDecision();
		}
	}

	private Decision<IntVar> getSubtreeDecision() {
		while (!subtree.isEmpty()) {
			int currentVar = subtree.removeFirst();
			int currentVal = subtree.removeFirst();
			IntVar best = vars[currentVar];
			if (best.isInstantiated()) {
				continue;
			}
			if (best.contains(currentVal)) {
				return solver.getDecisionPath().makeIntDecision(best, DecisionOperatorFactory.makeIntEq(), currentVal);
			}
		}
		return null;
	}

	@Override
	public void onSolution() {
		int obj = solver.getObjectiveManager().getObjective().asIntVar().getValue();
		if (sampling) {
			if (highQualitySamples.isBetterThanWorst(obj)) {
				int[] sol = new int[varNum];
				for (int i = 0; i < varNum; i++) {
					sol[i] = vars[i].getValue();
				}
				SolutionSample ss = new SolutionSample(sol, obj);
				highQualitySamples.addSample(ss);
			}
			currentSampleNum++;
			if (currentSampleNum >= maxSampleNum) {
				sampling = false;
				System.out.println("\n>>>>Sampling Done!");
				cancelRestartOnSolution();
				solver.unplugMonitor(this);
				geneSubtree();
				if (isMaximize) {
					solver.getObjectiveManager().updateBestLB(highQualitySamples.getBestSampleOBJ());
				} else {
					solver.getObjectiveManager().updateBestUB(highQualitySamples.getBestSampleOBJ());
				}

			}
		}
	}

	private void cancelRestartOnSolution() {
		Move m = solver.getMove();
		if (m == rfMove) {
			solver.setMove(rfMove.getChildMoves().get(0));
		} else {
			while (m.getChildMoves() != null && m.getChildMoves().get(0) != rfMove) {
				m = m.getChildMoves().get(0);
			}
			if (m.getChildMoves() != rfMove) {
				m.setChildMoves(rfMove.getChildMoves());
			}
		}
	}

	private void setRestartOnSolution() {
		rfMove = new MoveRestart(solver.getMove(), new MonotonicRestartStrategy(1),
				new SolutionCounter(solver.getModel(), 1), Integer.MAX_VALUE);
		solver.setMove(rfMove);
	}

	private void geneSubtree() {
		geneGoodFPs();
		subtree = new LinkedList<Integer>();
		if (goodFPs != null) {
			combineFPs();
		}
		System.out.println("\n>>>>Mining Done!");
		System.out.println(">>>>B&B Searching Starts ...... \n");
	}

	/**
	 * Do the mining in high quality samples and 
	 * store the sorted good frequent patterns in goodFPs.
	 */
	private void geneGoodFPs() {
		SolutionSample[] topSamples = highQualitySamples.getSamples();
		String[][] trans = new String[topSampleNum][];
		double[] qualities = new double[topSampleNum];
		for (int i = 0; i < topSampleNum; i++) {
			trans[i] = topSamples[i].getItems();
			qualities[i] = topSamples[i].getOBJ();
		}
		ECLAT eclat = new ECLAT(trans, isMaximize, qualities, minSup, shortestItemNum, longestItemNum, topFPnum);
		goodFPs = eclat.runFPM();
		int supThreshold = minSup;
		while (goodFPs == null) {//If no frequent pattern found, supThreshold is cut by half.
			supThreshold /= 2;
			if (supThreshold < 5) {
				break;
			}
			eclat = new ECLAT(trans, isMaximize, qualities, supThreshold, shortestItemNum, longestItemNum, topFPnum);
			goodFPs = eclat.runFPM();
		}
		if (shortestItemNum > 2) {//If no frequent pattern found, let the shortestItemNum=2 and try again.
			supThreshold = minSup;
			while (goodFPs == null) {
				supThreshold /= 2;
				if (supThreshold < 5) {
					break;
				}
				eclat = new ECLAT(trans, isMaximize, qualities, supThreshold, 2, longestItemNum, topFPnum);
				goodFPs = eclat.runFPM();
			}
		}
	}

	public void combineFPs() {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		for (int i = 0; i < goodFPs.length; i++) {//count the appearance of each assignment
			String[] ass = goodFPs[i].getItems();
			for (int j = 0; j < ass.length; j++) {
				String as = ass[j];
				if (!map.containsKey(as)) {
					map.put(as, 1);
				} else {
					int n = map.get(as);
					map.put(as, n + 1);
				}
			}
		}

		HashSet<Integer> varSet = new HashSet<Integer>();
		for (int i = 0; i < goodFPs.length; i++) {
			String[] ass = goodFPs[i].getItems();
			AssignmentInfo[] ais = new AssignmentInfo[ass.length];
			for (int j = 0; j < ass.length; j++) {
				String as = ass[j];
				int app = map.get(as);
				ais[j] = new AssignmentInfo(as, app);
			}
			Arrays.sort(ais, new Comparator<AssignmentInfo>() {
				public int compare(AssignmentInfo o1, AssignmentInfo o2) {
					if ((o1.app) > (o2.app)) {
						return -1;
					}
					if ((o1.app) < (o2.app)) {
						return 1;
					}
					return 0;
				}
			});

			for (int j = 0; j < ais.length; j++) {
				int vid = ais[j].varID;
				if (!varSet.contains(vid)) {
					varSet.add(vid);
					subtree.add(vid);
					int value = ais[j].value;
					subtree.add(value);
				}
			}
		}
	}

}

class AssignmentInfo {
	String as;
	int app;
	int varID;
	int value;

	public AssignmentInfo(String s, int a) {
		app = a;
		as = s;
		init();
	}

	private void init() {
		String[] sp = as.split("_");
		varID = Integer.parseInt(sp[0]);
		value = Integer.parseInt(sp[1]);
	}

}
