package org.nenu.fpms;
/**
 * This is a frequent pattern.
 * @author Hongbo Li, released 08/08/2021  
 */
public class FrequentPattern{

	private final int length;
	private final int supNum;
	private double basicScore;
	private double aveQuality;
	private double bestQuality;
	private double qualityScore;
	private double totalScore;
	private final String[] items;
	private final double[] qualities;
	private final boolean isMaximize;

	public FrequentPattern(int l, int s, String[] ass, double[] qs, boolean isMax) {
		length = l;
		supNum = s;
		basicScore = length * supNum;
		items = ass;
		qualities = qs;
		isMaximize = isMax;
		calQuality();
	}

	private void calQuality() {
		aveQuality = 0;
		for (int i = 0; i < qualities.length; i++) {
			aveQuality += qualities[i];
		}
		aveQuality /= length;
		if (isMaximize) {
			bestQuality = Double.MIN_VALUE;
			for (int i = 0; i < qualities.length; i++) {
				if (bestQuality < qualities[i]) {
					bestQuality = qualities[i];
				}
			}
		} else {
			bestQuality = Double.MAX_VALUE;
			for (int i = 0; i < qualities.length; i++) {
				if (bestQuality > qualities[i]) {
					bestQuality = qualities[i];
				}
			}
		}
		qualityScore = Math.sqrt(bestQuality * aveQuality);
		if (isMaximize) {
			totalScore = basicScore * qualityScore;
		} else {
			totalScore = basicScore / qualityScore;
		}
	}

	public boolean isBasicBetterThan(FrequentPattern fp) {
		return this.basicScore > fp.basicScore;
	}
	
	public double getTotalScore(){
		return totalScore;
	}
	public String[] getItems(){
		return items;
	}
	
}
