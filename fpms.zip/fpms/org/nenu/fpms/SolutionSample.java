package org.nenu.fpms;
/**
 * This is a sample solution.
 * @author Hongbo Li, released 08/08/2021  
 */
public class SolutionSample {
	
	private final int[] values;
	private final int obj;
	private final String[] items;// each item 'a_b' is an assignment of X[a]=b.
	private final int size;

	public SolutionSample(int[] vs, int o) {
		values = vs;
		obj = o;
		size = vs.length;
		items = new String[size];
		for (int i = 0; i < size; i++) {
			items[i] = i + "_" + values[i];
		}
	}

	public String[] getItems() {
		return items;
	}

	public int getOBJ() {
		return obj;
	}

}
