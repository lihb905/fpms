package org.nenu.fpms;

import java.util.Arrays;
import java.util.Comparator;

/**
 * This is a heap to store the top n frequent patterns.
 * @author Hongbo Li, released 08/08/2021  
 */
public class TopFrequentPatterns {

	private final int topNum;
	private int currentFPNum = 0;
	private FrequentPattern[] array;

	public TopFrequentPatterns(int n) {
		topNum = n;
		currentFPNum = 0;
		array = new FrequentPattern[topNum];
	}

	/**
	 * Each new frequent pattern will be added into the heap if its basicScore is
	 * better than that of the worst one in the heap.
	 * 
	 * @param fp
	 */
	public void add(FrequentPattern fp) {

		if (currentFPNum < topNum) {
			array[currentFPNum] = fp;
			int j = currentFPNum;
			int i = (j - 1) / 2;
			FrequentPattern temp = array[currentFPNum];
			while (j > 0) {
				if (temp.isBasicBetterThan(array[i])) {
					break;
				} else {
					FrequentPattern mid = array[j];
					array[j] = array[i];
					array[i] = mid;
					j = i;
					i = (i - 1) / 2;
				}
			}
			currentFPNum++;
		} else {
			if (fp.isBasicBetterThan(array[0])) {
				array[0] = fp;
				FrequentPattern temp = array[0];
				int i = 0;
				int j = 2 * i + 1;
				while (j < topNum) {
					if ((j < topNum - 1) && array[j].isBasicBetterThan(array[j + 1])) {
						j++;
					}
					if (array[j].isBasicBetterThan(temp)) {
						break;
					} else {
						FrequentPattern mid = array[j];
						array[j] = array[i];
						array[i] = mid;
						i = j;
						j = 2 * j + 1;
					}
				}
			}
		}

	}

	
	/**
	 * The top n frequent patterns will be sorted according to the measurement in the AAAI paper.
	 */
	private void sortFPs() {
		Arrays.sort(array, new Comparator<FrequentPattern>() {
			public int compare(FrequentPattern o1, FrequentPattern o2) {
				if ((o1.getTotalScore()) > (o2.getTotalScore())) {
					return -1;
				}
				if ((o1.getTotalScore()) < (o2.getTotalScore())) {
					return 1;
				}
				return 0;
			}
		});
	}

	public FrequentPattern[] getSortedFPs() {
		if (currentFPNum > 0) {
			if (currentFPNum < topNum) {
				array = Arrays.copyOf(array, currentFPNum);
			}
			sortFPs();
			return array;
		} else {
			return null;
		}

	}

}
