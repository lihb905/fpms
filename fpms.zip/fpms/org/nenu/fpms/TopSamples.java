package org.nenu.fpms;

/**
 * This is a heap to store the top k sample solutions.
 * @author Hongbo Li, released 08/08/2021 
 */
public class TopSamples {
	private final boolean isMaximize;
	private final int maxSize;
	private int currentSize;
	private SolutionSample[] samples;
	private int bestSampleOBJ;
	

	public TopSamples(int s, boolean isMax) {
		maxSize = s;
		isMaximize = isMax;
		currentSize = 0;
		samples = new SolutionSample[maxSize];
		if(isMaximize){
			bestSampleOBJ=Integer.MIN_VALUE;
		}else{
			bestSampleOBJ=Integer.MAX_VALUE;
		}
	}

	public boolean isBetterThanWorst(int obj) {
		if (currentSize < maxSize) {
			return true;
		}
		int worstOBJ = samples[0].getOBJ();
		if (isMaximize) {
			return obj > worstOBJ;
		} else {
			return obj < worstOBJ;
		}
	}
	

	public void addSample(SolutionSample ss) {
		if(isMaximize){
			if(bestSampleOBJ<ss.getOBJ()){
				bestSampleOBJ=ss.getOBJ();
			}
		}else{
			if(bestSampleOBJ>ss.getOBJ()){
				bestSampleOBJ=ss.getOBJ();
			}
		}
		
		if (currentSize < maxSize) {
			samples[currentSize] = ss;
			int j = currentSize;
			int i = (j - 1) / 2;
			SolutionSample temp = samples[currentSize];
			while (j > 0) {
				if (isBetter(temp, samples[i])) {
					break;
				} else {
					SolutionSample mid = samples[j];
					samples[j] = samples[i];
					samples[i] = mid;
					j = i;
					i = (i - 1) / 2;
				}
			}
			currentSize++;
		} else {
			if (isBetter(ss, samples[0])) {
				samples[0] = ss;
				SolutionSample temp = samples[0];
				int i = 0;
				int j = 2 * i + 1;
				while (j < maxSize) {
					if ((j < maxSize - 1) && isBetter(samples[j],samples[j + 1])) {
						j++;
					}
					if (isBetter(samples[j],temp)) {
						break;
					} else {
						SolutionSample mid = samples[j];
						samples[j] = samples[i];
						samples[i] = mid;
						i = j;
						j = 2 * j + 1;
					}
				}
			}
		}
	}

	private boolean isBetter(SolutionSample s1, SolutionSample s2) {
		if (isMaximize) {
			return s1.getOBJ() > s2.getOBJ();
		} else {
			return s1.getOBJ() < s2.getOBJ();
		}
	}
	
	public SolutionSample[] getSamples(){
		return samples;
	}
	
	public int getBestSampleOBJ(){
		return bestSampleOBJ;
	}
	

}
